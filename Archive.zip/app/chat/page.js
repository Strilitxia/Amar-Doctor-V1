"use client";

import { useState, useRef, useEffect } from "react";
import Navbar from "@/components/Navbar";
import SOSButton from "@/components/SOSButton";

const INITIAL_MESSAGES = [
  {
    id: "welcome-1",
    role: "ai",
    content:
      "আসসালামু আলাইকুম! আমি আপনার এআই ডাক্তার। আপনার শারীরিক সমস্যা বা লক্ষণ সম্পর্কে বলুন, আমি সাহায্য করতে চেষ্টা করবো।\n\nHello! I'm your AI Doctor. Please describe your symptoms or health concerns, and I'll do my best to help.",
    time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
  },
];

export default function ChatPage() {
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [mode, setMode] = useState("text"); // text | audio | video
  const [isListening, setIsListening] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState(null);
  const [voiceLang, setVoiceLang] = useState("bn-BD"); // bn-BD or en-US
  const [isAvatarTalking, setIsAvatarTalking] = useState(false);

  // Phase 4 Colab Endpoint State
  const [colabUrl, setColabUrl] = useState("");
  const [colabConnected, setColabConnected] = useState(false);
  const [showColabModal, setShowColabModal] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState("bn-BD-NabanitaNeural");

  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const recognitionRef = useRef(null);
  const audioPlayerRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Load stored Colab URL if available
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedUrl = localStorage.getItem("amar_doctor_colab_url");
      if (savedUrl) {
        setColabUrl(savedUrl);
        checkColabConnection(savedUrl);
      }
    }
  }, []);

  const checkColabConnection = async (url) => {
    try {
      const cleanUrl = url.trim().replace(/\/$/, "");
      const res = await fetch(`${cleanUrl}/health`, { method: "GET" });
      const data = await res.json();
      if (data.status === "online") {
        setColabConnected(true);
        localStorage.setItem("amar_doctor_colab_url", cleanUrl);
        return true;
      }
    } catch {
      setColabConnected(false);
    }
    return false;
  };

  // Setup Speech Recognition if available
  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = voiceLang;

        recognition.onresult = (event) => {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
          }
          setIsListening(false);
        };

        recognition.onerror = (event) => {
          console.warn("Speech recognition error:", event.error);
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      }
    }
  }, [voiceLang]);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition is not supported in this browser. Please type your message.");
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.lang = voiceLang;
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.warn("Recognition start err:", err);
      }
    }
  };

  const playNeuralAudio = (audioBase64) => {
    if (!audioPlayerRef.current) {
      audioPlayerRef.current = new Audio();
    }
    const player = audioPlayerRef.current;
    player.src = audioBase64;
    player.onplay = () => setIsAvatarTalking(true);
    player.onended = () => setIsAvatarTalking(false);
    player.onerror = () => setIsAvatarTalking(false);
    player.play().catch((e) => console.warn("Audio play error:", e));
  };

  const speakMessage = async (msgId, text) => {
    // 1. Try Colab Edge-TTS if connected
    if (colabConnected && colabUrl) {
      try {
        setSpeakingMsgId(msgId);
        setIsAvatarTalking(true);
        const res = await fetch(`${colabUrl}/api/tts`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text, voice: selectedVoice }),
        });
        const data = await res.json();
        if (data.audio_base64) {
          playNeuralAudio(data.audio_base64);
          return;
        }
      } catch (err) {
        console.warn("Colab TTS failed, falling back to browser speech:", err);
      }
    }

    // 2. Fallback to Browser Speech Synthesis
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      setIsAvatarTalking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.lang = voiceLang;

    utterance.onstart = () => {
      setSpeakingMsgId(msgId);
      setIsAvatarTalking(true);
    };

    utterance.onend = () => {
      setSpeakingMsgId(null);
      setIsAvatarTalking(false);
    };

    utterance.onerror = () => {
      setSpeakingMsgId(null);
      setIsAvatarTalking(false);
    };

    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async () => {
    const text = input.trim();
    if (!text) return;

    const userMsg = {
      id: `user-${Date.now()}`,
      role: "user",
      content: text,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    try {
      let aiReplyText = "";
      let neuralAudioB64 = null;

      // If Colab Backend is connected, query Colab consultation pipeline
      if (colabConnected && colabUrl) {
        try {
          const colabRes = await fetch(`${colabUrl}/api/chat-consultation`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: text,
              voice: selectedVoice,
              mode: mode,
              history: messages.map((m) => ({ role: m.role, content: m.content })),
            }),
          });
          const colabData = await colabRes.json();
          aiReplyText = colabData.reply;
          neuralAudioB64 = colabData.audio_base64;
        } catch (colabErr) {
          console.warn("Colab API error, fallback to Next.js API:", colabErr);
        }
      }

      // Default Next.js API route
      if (!aiReplyText) {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: text,
            history: messages.map((m) => ({ role: m.role, content: m.content })),
          }),
        });
        const data = await res.json();
        aiReplyText = data.reply || "I'm sorry, I couldn't process that. Please try again.";
      }

      const aiMsg = {
        id: `ai-${Date.now()}`,
        role: "ai",
        content: aiReplyText,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, aiMsg]);

      // Automatically speak in Audio or Video consultation modes
      if (mode === "audio" || mode === "video") {
        if (neuralAudioB64) {
          playNeuralAudio(neuralAudioB64);
        } else {
          speakMessage(aiMsg.id, aiReplyText);
        }
      }
    } catch {
      const errMsg = {
        id: `ai-err-${Date.now()}`,
        role: "ai",
        content: "Sorry, there was an error connecting to the AI service. Please check your connection.",
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      <Navbar />
      <div className="chat-page" id="chat-page">
        {/* Chat Header */}
        <div className="chat-header">
          <div className="chat-header__avatar">🩺</div>
          <div className="chat-header__info">
            <div className="chat-header__name">AI Doctor — এআই ডাক্তার</div>
            <div className="chat-header__status">
              <span className="dot"></span> 24/7 Live · Bengali & English Neural Assistant
            </div>
          </div>

          {/* Colab Sandbox Connection Indicator */}
          <button
            className="btn-ghost"
            onClick={() => setShowColabModal(true)}
            style={{
              padding: "4px 12px",
              fontSize: 11,
              borderColor: colabConnected ? "#34ed7b" : "rgba(106, 228, 255, 0.4)",
              color: colabConnected ? "#34ed7b" : "var(--color-fog-gray)",
            }}
            id="colab-settings-btn"
          >
            {colabConnected ? "⚡ Colab GPU Connected" : "🔌 Connect Colab / Edge-TTS"}
          </button>

          {/* Mode Toggle (Text / Audio / Video) */}
          <div className="chat-mode-toggle">
            <button
              className={`chat-mode-btn ${mode === "text" ? "active" : ""}`}
              onClick={() => setMode("text")}
            >
              💬 Text
            </button>
            <button
              className={`chat-mode-btn ${mode === "audio" ? "active" : ""}`}
              onClick={() => setMode("audio")}
            >
              🎙️ Audio (Low Bandwidth)
            </button>
            <button
              className={`chat-mode-btn ${mode === "video" ? "active" : ""}`}
              onClick={() => setMode("video")}
            >
              📹 Video Call
            </button>
          </div>
        </div>

        {/* Video / Audio Live Consultation Area */}
        {mode !== "text" && (
          <div
            style={{
              background: "var(--color-tide-card)",
              borderBottom: "1px solid var(--color-carbon-black)",
              padding: "20px 24px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "24px",
              flexWrap: "wrap",
            }}
          >
            {/* Doctor Avatar Box with Lip-sync & talking simulation */}
            <div
              style={{
                position: "relative",
                width: 130,
                height: 130,
                borderRadius: "var(--radius-cards)",
                background: "var(--color-abyss-navy)",
                border: isAvatarTalking
                  ? "2px solid var(--color-spectral-cyan)"
                  : "1px solid var(--color-carbon-black)",
                boxShadow: isAvatarTalking ? "0 0 20px rgba(106, 228, 255, 0.4)" : "none",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                transition: "all 0.3s ease",
              }}
            >
              <div style={{ fontSize: 52, transform: isAvatarTalking ? "scale(1.1)" : "scale(1)", transition: "transform 0.2s" }}>
                👨‍⚕️
              </div>
              <div style={{ fontSize: 10, color: "var(--color-spectral-cyan)", marginTop: 4, fontWeight: 600 }}>
                {isAvatarTalking ? "Speaking (কথা বলছেন)..." : "Listening (শুনছেন)"}
              </div>
            </div>

            {/* Video/Audio Controls & Telemetry */}
            <div style={{ maxWidth: 380 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                <span className="badge badge-cyan" style={{ fontSize: 11 }}>
                  {mode === "video" ? "📹 WebRTC Realtime Video Stream" : "🎙️ Neural Edge-TTS Voice Stream"}
                </span>
                {colabConnected && (
                  <span className="badge" style={{ background: "rgba(52, 237, 123, 0.2)", color: "#34ed7b", fontSize: 10 }}>
                    GPU Active
                  </span>
                )}
              </div>
              <p className="text-body-sm" style={{ fontWeight: 600, color: "var(--color-bone-white)", marginBottom: 4 }}>
                {mode === "video" ? "AI Doctor Video Consultation" : "Rural Low-Bandwidth Audio Mode"}
              </p>
              <p className="text-caption text-muted" style={{ lineHeight: 1.4 }}>
                {mode === "video"
                  ? "Live portrait lipsyncing to Bengali neural speech (Nabanita / Pradeep Neural). Automatically adapts for low-speed 2G/3G connections."
                  : "Optimized for rural mobile networks. Drops video completely and streams natural Bengali neural audio to save data."}
              </p>
            </div>
          </div>
        )}

        {/* Messages List */}
        <div className="chat-messages" id="chat-messages">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`chat-message chat-message--${msg.role === "user" ? "user" : "ai"}`}
            >
              <div className="chat-message__avatar">
                {msg.role === "user" ? "👤" : "🩺"}
              </div>
              <div>
                <div className="chat-message__bubble">
                  {msg.content.split("\n").map((line, i) => (
                    <span key={i}>
                      {line}
                      {i < msg.content.split("\n").length - 1 && <br />}
                    </span>
                  ))}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 4 }}>
                  <div className="chat-message__time">
                    {msg.role === "ai" ? "AI Doctor" : "You"} · {msg.time}
                  </div>
                  {msg.role === "ai" && (
                    <button
                      onClick={() => speakMessage(msg.id, msg.content)}
                      style={{
                        background: "none",
                        border: "none",
                        color: speakingMsgId === msg.id ? "var(--color-spectral-cyan)" : "var(--color-fog-gray)",
                        cursor: "pointer",
                        fontSize: 12,
                        padding: 0,
                      }}
                      title="Listen with Voice (ভয়েস শুনুন)"
                    >
                      {speakingMsgId === msg.id ? "⏹️ Stop" : "🔊 Listen"}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="chat-message chat-message--ai">
              <div className="chat-message__avatar">🩺</div>
              <div className="chat-message__bubble">
                <div className="typing-indicator">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input bar */}
        <div className="chat-input-bar" id="chat-input-bar">
          {/* Voice Language Selector */}
          <button
            className="btn-ghost"
            style={{ padding: "6px 10px", fontSize: 11, borderRadius: "var(--radius-badges)" }}
            onClick={() => setVoiceLang(voiceLang === "bn-BD" ? "en-US" : "bn-BD")}
            title="Switch Speech Language"
          >
            {voiceLang === "bn-BD" ? "বাংলা" : "ENG"}
          </button>

          {/* Microphone Voice Input Button */}
          <button
            onClick={toggleListening}
            style={{
              width: 40,
              height: 40,
              borderRadius: "50%",
              border: isListening ? "2px solid var(--color-sos-red)" : "1px solid var(--color-carbon-black)",
              background: isListening ? "rgba(255, 71, 87, 0.2)" : "var(--color-abyss-navy)",
              color: isListening ? "var(--color-sos-red)" : "var(--color-spectral-cyan)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              flexShrink: 0,
            }}
            aria-label="Voice input"
            title={isListening ? "Listening... Speak now" : "Speak to Doctor (মুখে বলুন)"}
            id="mic-button"
          >
            {isListening ? "🔴" : "🎙️"}
          </button>

          <input
            ref={inputRef}
            className="chat-input"
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isListening ? "Listening... বলুন..." : "আপনার লক্ষণ লিখুন বা বলুন... / Describe symptoms..."}
            disabled={isTyping}
            id="chat-input"
          />

          <button
            className="chat-send-btn"
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            aria-label="Send message"
            id="chat-send-btn"
          >
            ➤
          </button>
        </div>
      </div>

      {/* Colab Backend Configuration Modal */}
      {showColabModal && (
        <div className="sos-modal-overlay" onClick={() => setShowColabModal(false)}>
          <div className="sos-modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 500, textAlign: "left" }}>
            <h2 className="text-heading-sm" style={{ marginBottom: 8 }}>
              ⚡ Connect Colab AI Sandbox (Phase 4)
            </h2>
            <p className="text-body-sm text-muted" style={{ marginBottom: 16 }}>
              Paste your Google Colab (Cloudflare / Ngrok) public URL below to enable Microsoft Edge-TTS neural Bengali voices and SadTalker GPU avatar video synthesis.
            </p>

            <div style={{ marginBottom: 16 }}>
              <label className="text-caption text-muted" style={{ display: "block", marginBottom: 6, fontWeight: 600 }}>
                Colab / Backend Public URL (e.g. <code>https://xyz.trycloudflare.com</code> or <code>http://localhost:8000</code>)
              </label>
              <input
                type="text"
                className="chat-input"
                style={{ width: "100%", borderRadius: "var(--radius-cards)", padding: "10px 14px" }}
                placeholder="https://...trycloudflare.com"
                value={colabUrl}
                onChange={(e) => setColabUrl(e.target.value)}
              />
            </div>

            <div style={{ marginBottom: 20 }}>
              <label className="text-caption text-muted" style={{ display: "block", marginBottom: 6, fontWeight: 600 }}>
                Neural Bengali Voice Model
              </label>
              <select
                value={selectedVoice}
                onChange={(e) => setSelectedVoice(e.target.value)}
                style={{
                  width: "100%",
                  padding: "10px 14px",
                  borderRadius: "var(--radius-cards)",
                  background: "var(--color-abyss-navy)",
                  border: "1px solid var(--color-carbon-black)",
                  color: "var(--color-bone-white)",
                }}
              >
                <option value="bn-BD-NabanitaNeural">Nabanita (Female — প্রমিত বাংলা)</option>
                <option value="bn-BD-PradeepNeural">Pradeep (Male — গম্ভীর বাংলা)</option>
                <option value="en-US-JennyNeural">Jenny (English US)</option>
              </select>
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn-ghost" onClick={() => setShowColabModal(false)}>
                Cancel
              </button>
              <button
                className="btn-primary"
                onClick={async () => {
                  const ok = await checkColabConnection(colabUrl);
                  if (ok) {
                    alert("✓ Successfully connected to Amar Doctor Colab AI Backend!");
                    setShowColabModal(false);
                  } else {
                    alert("Could not reach backend at that URL. Please check that Colab / server is running.");
                  }
                }}
              >
                ✓ Test & Save Connection
              </button>
            </div>
          </div>
        </div>
      )}

      <SOSButton />
    </>
  );
}
